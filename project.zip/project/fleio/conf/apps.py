from django import apps


class AppConfig(apps.AppConfig):
    name = 'fleio.conf'
    verbose_name = 'Fleio configuration'
