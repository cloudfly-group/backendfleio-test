class PluginConfigTypes(object):
    # undefined
    undefined = 'undefined'

    enduser = 'enduser'
    reseller = 'reseller'
    staff = 'staff'
