default_app_config = 'fleio.core.apps.CoreAppConfig'

from .sms_providers.amazon_sms_provider.amazon_sms_provider import send_sms_as_task  # noqa
