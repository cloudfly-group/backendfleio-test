from fleio.core.dynamic_ui.dynamic_ui_view_base import DynamicUIViewBase
from fleio.core.plugins.plugin_config_types import PluginConfigTypes


class DynamicUIViewSet(DynamicUIViewBase):
    config_type = PluginConfigTypes.enduser
