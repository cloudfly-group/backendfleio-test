class AgreedTOSDestroyException(Exception):
    pass
