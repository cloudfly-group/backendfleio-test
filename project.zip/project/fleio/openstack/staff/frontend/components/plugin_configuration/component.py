from fleio.core.plugins.plugin_ui_component import PluginUIComponent


class PluginConfiguration(PluginUIComponent):
    features = ['openstack.cleanup']
