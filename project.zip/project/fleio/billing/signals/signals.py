# NOTE(tomo): Signals definitions goes here
