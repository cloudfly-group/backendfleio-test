default_app_config = 'fleio.billing.gateways.stripe.apps.StripeConfig'
