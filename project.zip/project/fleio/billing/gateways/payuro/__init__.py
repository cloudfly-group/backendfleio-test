default_app_config = 'fleio.billing.gateways.payuro.apps.PayURoConfig'
