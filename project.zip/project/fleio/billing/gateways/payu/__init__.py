default_app_config = 'fleio.billing.gateways.payu.apps.PayUConfig'
