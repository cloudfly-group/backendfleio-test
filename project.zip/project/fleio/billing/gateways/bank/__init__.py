default_app_config = 'fleio.billing.gateways.bank.apps.BankConfig'
